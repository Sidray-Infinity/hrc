package com.javabasics.question2;

public abstract class Book {
	String title;
	
	abstract void setTitle(String s);
	
	public String getTitle() {
		return this.title;
	}
}
