package com.javabasics.question1;

public class Arithmetic {
	int add(int a, int b) {
		return a+b;
	}
}


