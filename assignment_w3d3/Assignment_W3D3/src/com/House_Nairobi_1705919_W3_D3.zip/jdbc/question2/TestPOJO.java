package com.jdbc.question2;

public class TestPOJO {
	private String first_name;
	private String last_name;
	private Integer serial_number;
	private String also_known_as;
	private String moto;
	
	public TestPOJO() {
		
	}
	

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public Integer getSerial_number() {
		return serial_number;
	}

	public void setSerial_number(Integer serial_number) {
		this.serial_number = serial_number;
	}

	public String getAlso_known_as() {
		return also_known_as;
	}

	public void setAlso_known_as(String also_known_as) {
		this.also_known_as = also_known_as;
	}

	public String getMoto() {
		return moto;
	}

	public void setMoto(String moto) {
		this.moto = moto;
	}
	
	
}
